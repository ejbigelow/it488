IT488 files for use with  IT488-0322-0530-01, no other use is permitted.

This is the working directory for Eric Bigelow's (https://github.com/ejbigelow/it488) and Yenny Fernandez's IT488 Project.
