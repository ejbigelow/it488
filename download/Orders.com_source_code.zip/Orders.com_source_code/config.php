<?php
/**
 * Created by IntelliJ IDEA.
 * User: serrin
 * Date: 3/29/17
 * Time: 1:16 PM
 */

/**
 * THIS IS THE PRIMARY MACHINE CONFIGURATION THAT WILL ALLOW MULTIPLE MACHINES ACT INDEPENDENTLY PLEASE TYPE YOUR SEQUEL
 * SERVER PASSWORD BELOW.
 *
 */

//Do not change sqlUser
$sqlUser = 'root';

//Please change the password below to the password your sequel server is using
$sqlPassword = 'a7QWzJursnE7j2MY';
/*Database debug level*/
$debug = 2;
