<?php
/**
 * Created by IntelliJ IDEA.
 * User: serrin
 * Date: 4/27/17
 * Time: 10:45 AM
 * Adds color selector to items page
 */
?>
Available in 4 colors
<div class="row">
    <div style="background-color:red;height: 25px;" class="col-lg-1 color-select red"></div>
    <div style=";height: 25px;" class="col-lg-1 color-select white"></div>
    <div style="background-color:yellow;height: 25px;" class="col-lg-1 color-select yellow"></div>
    <div style="background-color:blue;height: 25px;" class="col-lg-1 color-select blue"></div>
</div>