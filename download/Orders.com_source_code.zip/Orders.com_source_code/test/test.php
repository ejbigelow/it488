<?php
/**
 * Created by IntelliJ IDEA.
 * User: serrin
 * Date: 4/29/17
 * Time: 2:52 PM
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>ACME llc. Order form:
        Catalog     </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <link href="css/custom.css" rel="stylesheet">
    <script>
    </script>
</head>
<body>
<div class="navbar navbar-default navbar-inverse navbar-fixed-top navbar-full">
    <div class="container-fluid">
        <!-- Logo -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".mainMenu">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand hidden-sm"></a>
        </div>
        <!-- Menu Items -->
        <div class="collapse navbar-collapse mainMenu">
            <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php?page=About">About</a></li>
                <li><a href="index.php?page=privacy">Privacy</a></li>
                <li><a href="index.php?page=services">Catalogue</a></li>
                <li><a href="index.php?page=events">Contact</a></li>
                <li><a href="index.php?page=help">Help</a></li>
            </ul>
            <!-- This entire section will remain hidden during phase1 but will be accessible via URL and challenge -->
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <form class="navbar-form pull-left hidden-md hidden-sm hidden-xs" role="search">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Search">
                        </div>
                        <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                    </form>
                </li>
                <!--User Sign-up -->
                <li><a href="#"><span class="glyphicon glyphicon-user"></span><span class="hidden-sm"> Sign Up</span></a></li>
                <!--User logon -->
                <li><a href="#"><span class="glyphicon glyphicon-log-in"></span><span class="hidden-sm">  Login</span></a></li>
            </ul>
            <!-- Stop hiding here -->
        </div>
    </div>
</div>
<!--
    This catalog code
-->
<div class="container">


    <!-- Carousel Header -->

    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <img src="images/patio.jpg" alt="Outdoor">
            </div>

            <div class="item">
                <img src="images/electronic.jpg" alt="Electronics">
            </div>

            <div class="item">
                <img src="images/household.jpeg" alt="Household appliances">
            </div>


        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <!--end carrusel -->

    <!-- Title -->
    <div class="row">
        <div class="col-lg-12">
            <h3>New Arrivals</h3>
        </div>
    </div>

﻿        <!-- /.row -->
<!-- Page Features -->
<div class="row text-center">
    <div class="col-md-3 col-sm-6 hero-feature">
        <div class="thumbnail">
            <img src="http://placehold.it/800x500" alt="">
            <div class="caption">
                <h3>Item #1</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                <p>
                    <a href="checkout.html" class="btn btn-primary"><span class="glyphicon glyphicon-shopping-cart align-left" aria-hidden="true"></span></a> <a href="description.htm" class="btn btn-default">view</a>
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 hero-feature">
        <div class="thumbnail">
            <img src="http://placehold.it/800x500" alt="">
            <div class="caption">
                <h3>Item #2</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                <p>
                    <a href="#" class="btn btn-primary"><span class="glyphicon glyphicon-shopping-cart align-left" aria-hidden="true"></span></a> <a href="#" class="btn btn-default">view</a>
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 hero-feature">
        <div class="thumbnail">
            <img src="http://placehold.it/800x500" alt="">
            <div class="caption">
                <h3>item #3</h3>
                <p>Product Description
                    Price: $ 2.00 .</p>
                <p>
                    <a href="#" class="btn btn-primary"><span class="glyphicon glyphicon-shopping-cart align-left" aria-hidden="true"></span></a> <a href="#" class="btn btn-default">view</a>
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 hero-feature">
        <div class="thumbnail">
            <img src="http://placehold.it/800x500" alt="">
            <div class="caption">
                <h3>item #4</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                <p>
                    <a href="#" class="btn btn-primary"><span class="glyphicon glyphicon-shopping-cart align-left" aria-hidden="true"></span></a> <a href="#" class="btn btn-default">view</a>
                </p>
            </div>
        </div>
    </div>
</div>
1234
</body>
